class TurnCounter:
    
    def __init__(self, turn):
        self.turn = turn
        
        #These two variables are used to tell html to allow player to make a turn and display the end screen data
        self.endstatus = False
        self.turnstatus = True
        
        self.message = "Empty"
        
        
        
        
    
    
    
    
    """
    - Increases Turn by 1 unless turn is 5
    
    - On Turn 5 it gets game stats and displays whether you won or not
    
    """
    
    def addTurn(self, mirror):
        newTurn = self.turn + 1
        if newTurn == 6:
            self.endstatus = True
            self.turnstatus = False
            self.message = decideGame(mirror)
        else:
            self.turn += 1
    """
    - restarts the turns and sets two flag variable back to default states
    """
    def reset(self):
        self.turn = 1
        self.endstatus = False
        self.turnstatus = True
        
        
#-------------GETTER---------------------------------------------------------
    """
    - gets different stats to display
    """
    def getTurn(self):
        return str(self.turn)
    def getEndStatus(self):
        return self.endstatus
    
    def getTurnStatus(self):
        return self.turnstatus
    def getMessage(self):
        return self.message
        

#-----------------------------------------------------------------------------
"""
- Gets Game state from mirror to decide game ending
"""
# decideGame FUNCTION
def decideGame(mirror):
    return mirror.getState()
