from flask import Flask, render_template, request, url_for
from inventory import Inventory
from mirror import Mirror
from turncounter import TurnCounter
app = Flask(__name__)
app.static_folder = 'static'

@app.route("/", methods=["GET", "POST"])
def index():
        
    #Renders page based on button one being clicked and uses item 1
    if request.method == "POST" and request.form.get("item1") == "item1":
        item = inventory.getFirstSlot()
        doTurn(item)
        inventory.setFirstSlot()

            
    #Renders page based on button second being clicked and uses item 2
    if request.method == "POST" and request.form.get("item2") == "item2":
        item = inventory.getSecondSlot()
        doTurn(item)
        inventory.setSecondSlot()

    
    
    
    
    
    #Renders page based on button three being clicked and uses item 3
    if request.method == "POST" and request.form.get("item3") == "item3":
        item = inventory.getThirdSlot()
        doTurn(item)
        inventory.setThirdSlot()
    
         
     #Renders page based on reset button one being clicked and restarts back to starting conditions
    if request.method == "POST" and request.form.get("restart") == "restart":
        restartGame()
    
    
    
    
    
    
    return render_template("index.html", turnState = turnCount.getTurnStatus(), endState = turnCount.getEndStatus(), \
                           button1 = inventory.getFirstSlot(), button2 = inventory.getSecondSlot(),button3 = inventory.getThirdSlot(), \
                           gameTurn = turnCount.getTurn(), \
                           mirrorImage = mirror.getImage(), endCondition = turnCount.getMessage(), \
                               Item1 = inventory.getFirstSlot().getImage(), Item2 = inventory.getSecondSlot().getImage(), Item3 = inventory.getThirdSlot().getImage(),\
                                   description1 = inventory.getFirstSlot().getDescription(), description2 = inventory.getSecondSlot().getDescription(), description3 = inventory.getThirdSlot().getDescription())



#----------------------------------------------------------------------------------------------------------------------------------------------------
"""
- Initializes the three objects needed to run
  the mirror, gamecounter, and inventory

"""
inventory = Inventory()
mirror = Mirror(50, 50)
turnCount = TurnCounter(1)

"""
- Function to make a turn pass

- Does what ever the item was just used does

- Then adds a turn 
"""
# doTurn FUNCTION
def doTurn(item):
    mirror.doEffect(item)
    turnCount.addTurn(mirror)
    
    
###############################################################################    

"""
- Restarts game by running the restart function on necessary objects
"""
# restartGame FUNCTION
def restartGame():
    turnCount.reset()
    mirror.restart()
    inventory.reset()
    
    
    

############################################################################# 
  

if __name__ == "__main__":
    app.run()