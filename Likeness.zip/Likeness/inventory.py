from item import Item
import random


class Inventory:
    def __init__(self):
        self.object1 = getItem()
        self.object2 = getItem()
        self.object3 = getItem()
        
    def __str__(self):
        return self.object1.getName()
    
    
    
    
#----SETTERS------------------------------------------------------------------    
    """
    - sets selected slot with a new random item
    """
    def setFirstSlot(self):
        self.object1 = getItem()
        
    def setSecondSlot(self):
        self.object2 = getItem()
        
    def setThirdSlot(self):
        self.object3 = getItem()
    
#-----GETTERS-----------------------------------------------------------------
    """
    - These just return the object for what ever was picked
    """
    def getFirstSlot(self):
        return self.object1
    
    def getSecondSlot(self):
        return self.object2
    def getThirdSlot(self):
        return self.object3
    
    
    """
    - Just randomizes inventory so player gets a fresh hand
    """
    def reset(self):
        self.setFirstSlot()
        self.setSecondSlot()
        self.setThirdSlot()



#---ITEMS-------------------------------------------------------------------

"""
Item actual descriptions
- Crab Apple: Adds 10 to positive stat, Minus 10 from negative

- Eyeball: Adds 10 to negative stat, Minus 10 from Positive

- Epic Milk: 50/50 to add 40 to either pos or negative

- Coin Toss: 50/50 to add 20 to either pos or negative

- Wild Card: 2/3 Chance to minus 30 from pos or negative, 1/3 to do nothing

- Silly Juice: If your winning, adds 30 to pos
                If losing, addss 30 to negative
                If neutral coin toss but with 10 as value

"""

crabApple = Item("Crab Apple", "Looks more like an apple than a crab. Adds 10 to positive stat, Minus 10 from negative")

coinToss = Item("Coin Toss", "Give it a toss. 50/50 to add 20 to either pos or negative")

sillyJuice = Item("Silly Juice", "The more the better. If your winning, adds 30 to pos\
                If losing, addss 30 to negative\
                If neutral coin toss but with 10 as value")

wildCard = Item("Wild Card", "Woah, this ones wild! 2/3 Chance to minus 30 from pos or negative, 1/3 to do nothing ")

epicMilk = Item("Epic Milk", "It says it expired today. Should still be good right? 50/50 to add 40 to either pos or negative")

eyeBall = Item("Eyeball", "Icky. How did that get there? Adds 10 to negative stat, Minus 10 from Positive")

  
itemList = [eyeBall,  sillyJuice, wildCard, epicMilk, coinToss, crabApple]




#---FUNCTIONS-------------------------------------------------------------

"""
- Gives a random item from the list
"""
def getItem():
    return random.choice(itemList)