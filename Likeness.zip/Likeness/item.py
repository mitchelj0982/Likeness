


class Item():
    
    def __init__(self, name, description):
        self.name = name
        self.description = description
        
    def __str__(self):
        return self.getName()
#--------GETTERS----------------------------------------------------

    """
    returns the items stats
    """
    def getName(self):
        return self.name
    
    def getDescription(self):
        return self.description
    
    """
    - Gets the proper image to be displayed on the web page
    """
    def getImage(self):
        imagePath = "static/assets/" + self.name +".png"
        return imagePath