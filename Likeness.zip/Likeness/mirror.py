import random

class Mirror:
    def __init__ (self, positive, negative):
        self.posNum = positive
        self.negNum = negative
        self.updateStats()
        
        
        
    
#----------GETTERS---------------------------------------------------------    
    """
    -Gets the image to display depending on mirror state
    """
    def getImage(self):
        if self.posNum > self.negNum:
            return "static/assets/good.png"
        elif self.negNum > self.posNum:
            return "static/assets/bad.png"
        elif self.negNum == self.posNum:
            return "static/assets/neutral.png"
    """
    - Gets general game state of whether youre winning losing or neutral
    """
    def getState(self):
        if self.posNum > self.negNum:
            return "Win"
        elif self.negNum > self.posNum:
            return "Loss"
        elif self.negNum == self.posNum:
            return "Draw"
            
    
    """
    - Gets Stats
    """
    def getPositive(self):
        return self.posNum
    
    def getNegative(self):
        return self.negNum
    
#----------SETTERS-------------------------------------------------------
    """
    - Sets stats
    """
    
    def setPositive(self, newVal):
        self.posNum = newVal
 
    
    def setNegative(self, newVal):
        self.negNum = newVal

    
    
#---------METHODS------------------------------------------------
    """
    - Resets Stats to a neutral 50/50
    """     
    def restart(self):
        self.posNum = 50
        self.negNum = 50
    """
    - Runs Validate stat calculations
    """
    def updateStats(self):
        validateStats(self.posNum, self.negNum, self)
    """
     - Does the item effect
     Item actual descriptions
     - Crab Apple: Adds 10 to positive stat, Minus 10 from negative

     - Eyeball: Adds 10 to negative stat, Minus 10 from Positive

     - Epic Milk: 50/50 to add 40 to either pos or negative

     - Coin Toss: 50/50 to add 20 to either pos or negative

     - Wild Card: 2/3 Chance to minus 30 from pos or negative, 1/3 to do nothing

     - Silly Juice: If your winning, adds 30 to pos
                     If losing, addss 30 to negative
                     If neutral coin toss but with 10 as value

    """
    def doEffect(self, obj):
        if obj.name == "Crab Apple":
            self.setPositive(self.getPositive() + 10)
            self.setNegative(self.getNegative() - 10)
        if obj.name == "Eyeball":
            self.setNegative(self.getNegative() + 10)
            self.setPositive(self.getPositive() - 10)
        if obj.name == "Epic Milk":
            num = random.randint(0, 1)
            if num == 1:
                self.setNegative(self.getNegative() + 40)
            else:
                self.setPositive(self.getPositive() + 40)
        if obj.name == "Coin Toss":
            num = random.randint(0, 1)
            if num == 1:
                self.setNegative(self.getNegative() + 20)
            else:
                self.setPositive(self.getPositive() + 20)
        if obj.name == "Wild Card":
            num = random.randint(0, 2)
            if num == 1:
                self.setNegative(self.getNegative() - 30)
            elif num == 0:
                self.setPositive(self.getPositive() - 30)
            else:
                self.setPositive(self.getPositive() + 0)
                
        if obj.name == "Silly Juice":
            if self.getState() == "Win":
                self.setPositive(self.getPositive() + 30)
            elif self.getState() == "Loss":
                self.setNegative(self.getNegative() + 30)
            else:
                num = random.randint(0, 1)
                if num == 1:
                    self.setNegative(self.getNegative() + 10)
                else:
                    self.setPositive(self.getPositive() + 10)
                
            
            
            
            
            
        
"""
- Just caps stats so they can't be greater than 100,
  or less than 0
"""      
def validateStats(pos, neg, obj):
    positiveValue = pos
    negativeValue = neg
    
    if pos > 100:
        positiveValue = 100
    if pos < 0:
        positiveValue = 0
        
    if neg > 100:
        negativeValue = 100
    if neg < 0:
        negativeValue = 0
    
    obj.setPositive(positiveValue)
    obj.setNegative(negativeValue)
    
        
        
        
        
        
        
        
        
        

    